'use client'

import { useEffect, useState } from 'react'
import { useParams, useRouter } from 'next/navigation'
import Link from 'next/link'
import ReactMarkdown from 'react-markdown'
import {
  ChevronLeft, MessageSquare, BookOpen, Sparkles, Volume2, Bookmark, Settings, Send, X
} from 'lucide-react'

type Loaded = {
  title: string | null
  format: 'markdown' | 'text'
  content: string
}

export default function LearningPage() {
  const params = useParams()
  const router = useRouter()
  const materialId = params.id as string

  const [selectedText, setSelectedText] = useState('')
  const [question, setQuestion] = useState('')
  const [chatHistory, setChatHistory] = useState<Array<{ role: string; content: string }>>([])
  const [loading, setLoading] = useState(false)

  // ★ 로드된 본문
  const [doc, setDoc] = useState<Loaded | null>(null)
  const [loadingDoc, setLoadingDoc] = useState(true)
  const [docError, setDocError] = useState<string | null>(null)

  // 초기 로드
  useEffect(() => {
    (async () => {
      setLoadingDoc(true)
      setDocError(null)
      try {
        const res = await fetch(`/api/materials/${materialId}/content`)
        if (!res.ok) {
          const { error } = await res.json().catch(() => ({ error: 'Load failed' }))
          setDocError(error || 'Load failed')
        } else {
          const data = await res.json()
          setDoc({
            title: data.material?.title ?? null,
            format: data.format,
            content: data.content,
          })
        }
      } catch (e) {
        setDocError('네트워크 오류가 발생했습니다.')
      } finally {
        setLoadingDoc(false)
      }
    })()
  }, [materialId])

  function handleTextSelection() {
    const selection = window.getSelection()
    const text = selection?.toString().trim()
    if (text) setSelectedText(text)
  }

  async function handleAskQuestion(e: React.FormEvent) {
    e.preventDefault()
    if (!question.trim() || !doc) return

    setLoading(true)
    setChatHistory((prev) => [...prev, { role: 'user', content: question }])

    try {
      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          selectedText,
          question,
          // ★ 학습 문맥에 실제 로드된 본문 전달
          context: doc.content,
        }),
      })

      const data = await response.json()
      setChatHistory((prev) => [...prev, { role: 'assistant', content: data.response }])
      setQuestion('')
    } catch (error) {
      console.error('Chat error:', error)
      setChatHistory((prev) => [
        ...prev,
        { role: 'assistant', content: '오류가 발생했습니다. 다시 시도해주세요.' },
      ])
    } finally {
      setLoading(false)
    }
  }

  function handleNotImplemented(feature: string) {
    alert(`'${feature}' 기능은 아직 구현되지 않았습니다.`)
    router.push('/dashboard')
  }

  return (
    <div className="min-h-screen flex bg-[#FAF7F2]">
      <div className="flex-1 flex flex-col">
        {/* Header */}
        <header className="border-b border-[#E6E0D6] bg-surface">
          <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8 py-4 flex justify-between items-center">
            <Link href="/dashboard" className="flex items-center gap-2">
              <div className="w-8 h-8 bg-[#76B88A] rounded-lg flex items-center justify-center text-white font-bold">
                L
              </div>
              <h1 className="text-2xl font-bold text-[#1A1A1A]">Lango</h1>
            </Link>
            <div className="flex items-center gap-2">
              <button onClick={() => handleNotImplemented('북마크')} className="p-2 hover:bg-[#E6E0D6]/30 rounded-lg transition-colors text-[#5E5E5E]">
                <Bookmark className="h-5 w-5" />
              </button>
              <button onClick={() => handleNotImplemented('설정')} className="p-2 hover:bg-[#E6E0D6]/30 rounded-lg transition-colors text-[#5E5E5E]">
                <Settings className="h-5 w-5" />
              </button>
              <Link href="/dashboard" className="px-4 py-2 text-[#5E5E5E] hover:text-[#1A1A1A] transition-colors flex items-center gap-1">
                <ChevronLeft className="h-4 w-4" />
                대시보드
              </Link>
            </div>
          </div>
        </header>

        {/* Top Bar */}
        <div className="border-b border-[#E6E0D6] bg-surface px-4 md:px-8 py-3">
          <div className="flex items-center justify-between max-w-[1440px] mx-auto">
            <div className="flex items-center gap-3">
              <BookOpen className="h-5 w-5 text-[#76B88A]" />
              <h2 className="text-[#1A1A1A]" style={{ fontSize: '16px', fontWeight: 600 }}>
                {doc?.title ?? '학습 중'}
              </h2>
            </div>
            <div className="flex items-center gap-2">
              <button onClick={() => handleNotImplemented('음성 읽기')} className="px-3 py-1.5 text-sm bg-[#E6E0D6]/50 text-[#5E5E5E] hover:bg-[#E6E0D6] rounded-lg transition-colors flex items-center gap-1.5">
                <Volume2 className="h-4 w-4" />
                <span className="hidden sm:inline">읽어주기</span>
              </button>
            </div>
          </div>
        </div>

        {/* Main Content */}
        <main className="flex-1 overflow-hidden">
          <div className="h-full max-w-[1440px] mx-auto px-4 md:px-8 py-6">
            <div className="grid md:grid-cols-[1fr_400px] gap-6 h-full">
              {/* Document Viewer */}
              <div className="bg-surface rounded-lg border border-[#E6E0D6] p-8 overflow-y-auto">
                {loadingDoc ? (
                  <p className="text-[#5E5E5E]">본문을 불러오는 중...</p>
                ) : docError ? (
                  <div className="text-[#5E5E5E]">
                    <p>본문을 불러오지 못했습니다: {docError}</p>
                    <button className="mt-2 px-3 py-1.5 bg-[#E6E0D6]/50 rounded" onClick={() => router.push('/dashboard')}>
                      대시보드로 돌아가기
                    </button>
                  </div>
                ) : doc ? (
                  <div
                    onMouseUp={handleTextSelection}
                    className="prose prose-lg max-w-none"
                    style={{ color: '#1A1A1A', lineHeight: '1.8' }}
                  >
                    {doc.format === 'markdown' ? (
                      <ReactMarkdown>{doc.content}</ReactMarkdown>
                    ) : (
                      <pre className="whitespace-pre-wrap">{doc.content}</pre>
                    )}
                  </div>
                ) : null}

                {/* Selected Text Popup */}
                {selectedText && (
                  <div className="mt-6 p-4 bg-[#76B88A]/10 rounded-lg border border-[#76B88A]/30 relative">
                    <button onClick={() => setSelectedText('')} className="absolute top-2 right-2 p-1 hover:bg-[#76B88A]/20 rounded transition-colors">
                      <X className="h-4 w-4 text-[#5E5E5E]" />
                    </button>
                    <p className="text-xs text-[#5E5E5E] mb-2 font-medium">선택된 텍스트:</p>
                    <p className="text-[#1A1A1A] font-medium mb-3" style={{ fontSize: '14px' }}>{selectedText}</p>
                    <div className="flex gap-2">
                      <button onClick={() => setQuestion(`"${selectedText}"의 의미를 설명해주세요.`)} className="px-3 py-1.5 text-xs bg-[#76B88A] text-white rounded-lg hover:bg-[#76B88A]/90 transition-colors font-medium">
                        의미 설명
                      </button>
                      <button onClick={() => setQuestion(`"${selectedText}"의 문법을 분석해주세요.`)} className="px-3 py-1.5 text-xs bg-[#C8B79A] text-white rounded-lg hover:bg-[#C8B79A]/90 transition-colors font-medium">
                        문법 분석
                      </button>
                    </div>
                  </div>
                )}
              </div>

              {/* AI Chat Panel (변경 없음, context만 doc.content 사용) */}
              <div className="bg-surface rounded-lg border border-[#E6E0D6] flex flex-col h-full max-h-[calc(100vh-200px)]">
                <div className="p-4 border-b border-[#E6E0D6]">
                  <div className="flex items-center gap-2">
                    <div className="w-8 h-8 rounded-full bg-[#76B88A]/10 flex items-center justify-center">
                      <Sparkles className="h-4 w-4 text-[#76B88A]" />
                    </div>
                    <div>
                      <h3 className="text-[#1A1A1A] font-semibold" style={{ fontSize: '15px' }}>
                        AI 튜터
                      </h3>
                      <p className="text-[#5E5E5E]" style={{ fontSize: '11px' }}>
                        질문하고 학습하세요
                      </p>
                    </div>
                  </div>
                </div>

                <div className="flex-1 overflow-y-auto p-4 space-y-3">
                  {chatHistory.length === 0 ? (
                    <div className="h-full flex items-center justify-center">
                      <div className="text-center">
                        <MessageSquare className="h-12 w-12 text-[#C8B79A]/30 mx-auto mb-3" />
                        <p className="text-[#5E5E5E]" style={{ fontSize: '13px' }}>
                          텍스트를 선택하거나<br />질문을 입력해보세요
                        </p>
                      </div>
                    </div>
                  ) : (
                    chatHistory.map((message, index) => (
                      <div key={index} className={`flex ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                        <div className={`max-w-[85%] p-3 rounded-lg ${message.role === 'user' ? 'bg-[#76B88A] text-white' : 'bg-[#E6E0D6]/50 text-[#1A1A1A]'}`}>
                          <p className="text-xs mb-1 opacity-70">
                            {message.role === 'user' ? '나' : 'AI 튜터'}
                          </p>
                          <div className="text-sm" style={{ lineHeight: '1.5' }}>
                            <ReactMarkdown>{message.content}</ReactMarkdown>
                          </div>
                        </div>
                      </div>
                    ))
                  )}
                </div>

                <div className="p-4 border-t border-[#E6E0D6]">
                  <form onSubmit={handleAskQuestion} className="space-y-2">
                    <div className="relative">
                      <textarea
                        value={question}
                        onChange={(e) => setQuestion(e.target.value)}
                        placeholder="질문을 입력하세요..."
                        className="w-full px-4 py-3 pr-12 border border-[#E6E0D6] rounded-lg focus:outline-none focus:ring-2 focus:ring-[#76B88A] resize-none bg-white text-[#1A1A1A]"
                        rows={3}
                        style={{ fontSize: '14px' }}
                      />
                      <button
                        type="submit"
                        disabled={loading || !question.trim()}
                        className="absolute bottom-3 right-3 p-2 bg-[#76B88A] text-white rounded-lg hover:bg-[#76B88A]/90 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                      >
                        <Send className="h-4 w-4" />
                      </button>
                    </div>
                    {loading && <p className="text-xs text-[#5E5E5E] text-center">답변 생성 중...</p>}
                  </form>

                  <div className="mt-3 pt-3 border-t border-[#E6E0D6]/50 grid grid-cols-2 gap-2">
                    <button
                      onClick={() => (selectedText ? setQuestion(`"${selectedText}"의 의미를 설명해주세요.`) : alert('먼저 텍스트를 선택해주세요.'))}
                      disabled={!selectedText}
                      className="px-3 py-2 text-xs text-[#5E5E5E] bg-[#E6E0D6]/30 hover:bg-[#E6E0D6]/50 rounded-lg transition-colors disabled:opacity-40 disabled:cursor-not-allowed font-medium"
                    >
                      선택 텍스트 설명
                    </button>
                    <button
                      onClick={() => (selectedText ? setQuestion(`"${selectedText}"의 문법을 분석해주세요.`) : alert('먼저 텍스트를 선택해주세요.'))}
                      disabled={!selectedText}
                      className="px-3 py-2 text-xs text-[#5E5E5E] bg-[#E6E0D6]/30 hover:bg-[#E6E0D6]/50 rounded-lg transition-colors disabled:opacity-40 disabled:cursor-not-allowed font-medium"
                    >
                      문법 분석
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </main>
      </div>
    </div>
  )
}
